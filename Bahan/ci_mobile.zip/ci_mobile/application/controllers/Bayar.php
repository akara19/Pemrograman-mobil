<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bayar extends CI_Controller {
	public function index()
	{
		$data['siswa'] = $this->db->get('tb_siswa')->result();
        $data['jenis_bayar'] = $this->db->get('tb_jenis_bayar')->result();
        $this->template->load('Dashboard','Bayar',$data);
	}

    public function Simpan(){
        $Kode_siswa = $this->input->post('Kode_siswa');
        $Kode_bayar = $this->input->post('Kode_bayar');
        $Qty = $this->input->post('Qty');
        $data = array('Kode_siswa'=>$Kode_siswa,
                      'Kode_jenis'=>$Kode_bayar,
                      'Qty'=>$Qty  );
        $this->db->insert('tb_bayar',$data);
       //echo "<meta http-equiv='refresh' content='0; url="
       //.base_url()."index.php/Bayar'>";
    }

    public function Lihat(){
        $data['siswa'] = $this->db->get('tb_siswa')->result();
        $this->template->load('Dashboard','SiswaLihat',$data);
    }
	
	public function Edit(){
		$Kode=$this->uri->segment(3);
		$data['siswa'] = $this->db->get_where('tb_siswa',
		array('Kode'=>$Kode),0,0)->result();
		$this->template->load('Dashboard','SiswaEdit',$data);
    }
	
	 public function Update(){
		$Kode = $this->input->post('Kode');
		$Nama = $this->input->post('Nama');
        $Alamat = $this->input->post('Alamat');
		
		$data = array('Nama'=>$Nama,
                      'Alamat'=>$Alamat);
		$this->db->where('Kode',$Kode);
		$this->db->update('tb_siswa',$data);
		echo "<meta http-equiv='refresh' content='0; url=".
		base_url()."index.php/Siswa/Lihat'>";
	}
	
	 public function Delete(){
		$Kode = $this->uri->segment(3);
		$this->db->where('Kode',$Kode);
		$this->db->delete('tb_siswa');
		echo "<meta http-equiv='refresh' content='0; url=".
		base_url()."index.php/Siswa/Lihat'>";
	}
	
	
}
