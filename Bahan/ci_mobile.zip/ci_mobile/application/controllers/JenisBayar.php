<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class JenisBayar extends CI_Controller {
	public function index()
	{
		$this->template->load('Dashboard','JenisBayar');
	}

    public function Simpan(){
        $Jenis = $this->input->post('Jenis');
        $Nominal = $this->input->post('Nominal');
        $data = array('Jenis_bayar'=>$Jenis,
                      'Nominal'=>$Nominal);
        $this->db->insert('tb_jenis_bayar',$data);

       echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/JenisBayar'>";
    }

    public function Lihat(){
        $data['jenis'] = $this->db->get('tb_jenis_bayar')->result();
        $this->template->load('Dashboard','LihatJenisBayar',$data);
    }
	
	
	 public function Edit(){
		$Kode=$this->uri->segment(3);
		$data['jenis'] = $this->db->get_where('tb_jenis_bayar',
		array('Kode'=>$Kode),0,0)->result();
		$this->template->load('Dashboard','JenisBayarEdit',$data);
    }
	
	 public function Update(){
		$Kode = $this->input->post('Kode');
		$Jenis = $this->input->post('Jenis');
        $Nominal = $this->input->post('Nominal');
		
		$data = array('Jenis_bayar'=>$Jenis,
                      'Nominal'=>$Nominal);
		$this->db->where('Kode',$Kode);
		$this->db->update('tb_jenis_bayar',$data);
		echo "<meta http-equiv='refresh' content='0; url=".
		base_url()."index.php/JenisBayar/Lihat'>";
	}
	
	 public function Delete(){
		$Kode = $this->uri->segment(3);
		$this->db->where('Kode',$Kode);
		$this->db->delete('tb_jenis_bayar');
		echo "<meta http-equiv='refresh' content='0; url=".
		base_url()."index.php/JenisBayar/Lihat'>";
	}
	
	
}
