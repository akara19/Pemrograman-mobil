<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa extends CI_Controller {
	public function index()
	{
		$this->template->load('Dashboard','Siswa');
	}

    public function Simpan(){
        $Nama = $this->input->post('Nama');
        $Alamat = $this->input->post('Alamat');
        $data = array('Nama'=>$Nama,
                      'Alamat'=>$Alamat);
        $this->db->insert('tb_siswa',$data);
       echo "<meta http-equiv='refresh' content='0; url="
       .base_url()."index.php/Siswa'>";
    }

    public function Lihat(){
        $data['siswa'] = $this->db->get('tb_siswa')->result();
        $this->template->load('Dashboard','SiswaLihat',$data);
    }
	
	public function Edit(){
		$Kode=$this->uri->segment(3);
		$data['siswa'] = $this->db->get_where('tb_siswa',
		array('Kode'=>$Kode),0,0)->result();
		$this->template->load('Dashboard','SiswaEdit',$data);
    }
	
	 public function Update(){
		$Kode = $this->input->post('Kode');
		$Nama = $this->input->post('Nama');
        $Alamat = $this->input->post('Alamat');
		
		$data = array('Nama'=>$Nama,
                      'Alamat'=>$Alamat);
		$this->db->where('Kode',$Kode);
		$this->db->update('tb_siswa',$data);
		echo "<meta http-equiv='refresh' content='0; url=".
		base_url()."index.php/Siswa/Lihat'>";
	}
	
	 public function Delete(){
		$Kode = $this->uri->segment(3);
		$this->db->where('Kode',$Kode);
		$this->db->delete('tb_siswa');
		echo "<meta http-equiv='refresh' content='0; url=".
		base_url()."index.php/Siswa/Lihat'>";
	}
	
	
}
