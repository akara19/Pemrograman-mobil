<div class="content">
	<div class="container-fluid">
        <div class="row">
			<?php echo form_open_multipart('Bayar/Simpan');?>
                <div class="form-group">
                    <label>Nama Siswa</label>
                    <select name="Kode_siswa">
                        <?php 
                            foreach ($siswa as $_siswa){
                        ?>
                            <option value="<?php echo $_siswa->Kode; ?>" >
                            <?php echo $_siswa->Nama;  ?>
                            </option>
                        <?php        
                            }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Jenis Bayar</label>
                    <select name="Kode_bayar">
                        <?php
                            foreach ($jenis_bayar as $_jenis_bayar){
                        ?>
                            <option value="<?php echo $_jenis_bayar->Kode;?>">
                            <?php echo $_jenis_bayar->Jenis_bayar; ?>
                            </option>
                        <?php
                            }
                        ?>
                    </select>
                </div>
				
                <div class="form-group">
                    <label>Qty</label>
                    <input type="text" name="Qty">
                </div>

                <div class="form-group">
                    <input type="submit" value="Simpan" class="btn btn-success">
                    <a href="<?php echo base_url('index.php/Siswa/Lihat'); ?>">
                        <input type="button" value="Lihat Data" 
                        class="btn btn-danger">
                    </a>
                </div>
            </form>
            
		</div>
	</div>
</div>
