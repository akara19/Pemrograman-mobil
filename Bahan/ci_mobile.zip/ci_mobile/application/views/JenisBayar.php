<div class="content">
	<div class="container-fluid">
        <div class="row">
			<?php echo form_open_multipart('JenisBayar/Simpan');?>
                <div class="form-group">
                    <label>Jenis Bayar</label>
                    <input type="text" class="form-control" name="Jenis">
                </div>
                <div class="form-group">
                    <label>Nominal</label>
                    <input type="text" class="form-control" name="Nominal">
                </div>
				
                <div class="form-group">
                    <input type="submit" value="Simpan" class="btn btn-success">
                    <a href="<?php echo base_url('index.php/JenisBayar/Lihat'); ?>">
                        <input type="button" value="Lihat Data" 
                        class="btn btn-danger">
                    </a>
                </div>
            </form>
            
		</div>
	</div>
</div>
