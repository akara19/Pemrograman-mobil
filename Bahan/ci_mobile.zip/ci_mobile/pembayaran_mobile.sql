/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50716
Source Host           : localhost:3306
Source Database       : pembayaran_mobile

Target Server Type    : MYSQL
Target Server Version : 50716
File Encoding         : 65001

Date: 2022-04-25 20:35:33
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_bayar`
-- ----------------------------
DROP TABLE IF EXISTS `tb_bayar`;
CREATE TABLE `tb_bayar` (
  `Kode` int(11) NOT NULL AUTO_INCREMENT,
  `Kode_siswa` int(11) DEFAULT NULL,
  `Kode_jenis` int(11) DEFAULT NULL,
  `Qty` int(11) DEFAULT NULL,
  `Nominal` int(11) DEFAULT NULL,
  `Tanggal` date DEFAULT NULL,
  `Created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_bayar
-- ----------------------------

-- ----------------------------
-- Table structure for `tb_jenis_bayar`
-- ----------------------------
DROP TABLE IF EXISTS `tb_jenis_bayar`;
CREATE TABLE `tb_jenis_bayar` (
  `Kode` int(11) NOT NULL AUTO_INCREMENT,
  `Jenis_bayar` varchar(255) DEFAULT NULL,
  `Nominal` int(11) DEFAULT NULL,
  PRIMARY KEY (`Kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_jenis_bayar
-- ----------------------------

-- ----------------------------
-- Table structure for `tb_siswa`
-- ----------------------------
DROP TABLE IF EXISTS `tb_siswa`;
CREATE TABLE `tb_siswa` (
  `Kode` int(11) NOT NULL AUTO_INCREMENT,
  `Nama` varchar(255) DEFAULT NULL,
  `Alamat` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_siswa
-- ----------------------------
DROP TRIGGER IF EXISTS `get_nominal`;
DELIMITER ;;
CREATE TRIGGER `get_nominal` BEFORE INSERT ON `tb_bayar` FOR EACH ROW BEGIN
SET NEW.Nominal = (SELECT Nominal FROM tb_jenis_bayar WHERE Kode=NEW.Kode_jenis);
END
;;
DELIMITER ;
