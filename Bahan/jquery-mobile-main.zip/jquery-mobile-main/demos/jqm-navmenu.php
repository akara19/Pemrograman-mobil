	    <div data-role="panel" class="jqm-navmenu-panel" data-position="left" data-display="overlay" data-theme="a">
	    	<ul class="ui-alt-icon ui-nodisc-icon">
				<li data-role='list-divider'>Menu</li>
		     	<?php include( 'jqm-contents.php' ); ?>
		     </ul>
		</div><!-- /panel -->
