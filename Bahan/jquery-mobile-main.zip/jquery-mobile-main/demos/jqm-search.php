<div class="jqm-search-panel">
	<div class="jqm-search">
		<form class="ui-alt-icon ui-nodisc-icon">
			<input data-type="search" name="search" id="jqm-search-input" class="jqm-search-input" placeholder="Search demos...">
		</form>
		<ul class="jqm-search-list" data-filter="true" data-filter-reveal="true" data-input="#jqm-search-input">
			<?php include( 'jqm-contents.php' ); ?>
		</ul>
	</div>
</div><!-- /panel -->
