<?php
error_reporting(0);
class Jurusan extends CI_Controller{

	// __contructor default dari controlle
	function __construct() {
		parent::__construct();
		$this->load->helper(array('form','url','text_helper','date'));
		$this->load->database();
		$this->load->library(array('Pagination','user_agent'));
	}
	function index(){
		$this->template->load('dashboard','webadmin/Jurusan/insert');
	}
	
	function Insert(){
		$Nama = $this->input->post('Nama');
        $data = array('Nama'=>$Nama);
        $this->db->insert('tb_jurusan',$data);
        $this->session->set_flashdata('msg', 
        '<div class="alert alert-success alert-dismissible fade in">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>Data baru berhasil disimpan</strong>
            </div>');
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/Jurusan'>";
	}

	public function Select(){
        $data['jurusan'] = $this->db->get('tb_jurusan')->result();
        $this->template->load('dashboard','webadmin/Jurusan/select',$data);
    }

	// Form Edit untuk tabel ppi_mahasiswa berfungsi untuk memanggil form edit atau ubah data
	function Edit(){
		$id=$this->uri->segment(3);
		$data['jurusan'] = $this->db->get_where('tb_jurusan',array('id'=>$id),0,0)->result();
		$this->template->load('dashboard','webadmin/Jurusan/edit',$data);
	}
	// Method atau function untuk menangkap data form ppi_mahasiswa
	// dan selanjut nya akan di lempar ke SP Update
	// dan melakukan penyimpanan data pada tabel ppi_mahasiswa
	function Update(){
		// variabel yang digunakan sebagai acuan untuk melakukan proses Update
		$id = $this->input->post('id');
		// Variabel yang digunakan untuk menamgkap isi dari form input data
		$Nama = $this->input->post('Nama');
		
		// Memanggil method atau fungsi untuk menyimpan data pada Model 
		$data = array('Nama'=>$Nama);
		$this->db->where('id',$id);
		$this->db->update('tb_jurusan',$data);
		$this->session->set_flashdata('msg', 
        '<div class="alert alert-success alert-dismissible fade in">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>Perubahan data berhasil disimpan</strong>
            </div>');
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/Jurusan/Select'>";
	}
	// form tambah data untuk tabel ppi_mahasiswa
	function Delete(){
		$id = $this->uri->segment(3);
		$this->db->where('id',$id);
		$this->db->delete('tb_jurusan');
		echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/Jurusan/Select'>";
	}

// End Class
}
?>
