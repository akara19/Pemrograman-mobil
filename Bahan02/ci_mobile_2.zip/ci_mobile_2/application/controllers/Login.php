<?php

error_reporting(0);

class Login extends CI_Controller{



	function __construct() {

		parent::__construct();

        $this->load->helper(array('form','url', 'text_helper','date'));

		$this->load->database();

		$this->load->library(array('Pagination','user_agent'));

		$this->load->model('Ppi_user_model');

	}

	

	function index(){

		$this->load->view('login');

	}



	function Auth(){

		$fNim = $this->input->post('Nim');

		$fPswd = $this->input->post('Pswd');

		

		$hasil 		= $this->Ppi_user_model->user_cek($fNim,$fPswd);



		if (count($hasil->result_array())>0){

			foreach($hasil->result() as $items){

				$session_username=$items->ppi_id."|".$items->Nim."|". $items->Nama."|".$items->Url_key;

			}

			$_SESSION['mahasiswa_login']=$session_username;

			echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/Biodata'>";

		}

		else{

			?>

			

			<script type="text/javascript">

			alert("Username atau Password Yang Anda Masukkan Salah..!!!");

			</script> 

									

			<?php

			echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/Login'>";

		}

	}

	

	function Change_password(){

		$this->template->load('dashboard','webadmin/dashboard/change_password');

	}

	

	function Update_password(){

		$session = isset($_SESSION['mahasiswa_login']) ? $_SESSION['mahasiswa_login']:'';

		$pecah = explode("|",$session);

		$data["ppi_id"]		= $pecah[0];

		$data["Nim"]		= $pecah[1];

		$data["Nama"]		= $pecah[2];

		$data["Url_key"]	= $pecah[3];

		$Pswd =  $this->input->post('password');

		//echo $data['Nim'];

		//echo $Pswd;

		$this->Ppi_user_model->update_password($data['Nim'],$Pswd);

		$this->session->set_flashdata('msg', 

                '<div class="alert alert-success">

                    <h4>Berhasil </h4>

                    <p>Password berhasil di ubah, untuk mencoba silahkan Log-out dan Login lagi</p>

                </div>');

       $this->template->load('dashboard','webadmin/dashboard/change_password');

	}

	

	function Logout(){

		session_destroy();

		echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/Login'>";

	}

	

	function loginpage(){

		$data = array();

		$session=isset($_SESSION['mahasiswa_login']) ? $_SESSION['mahasiswa_login']:'';

		if($session!=""){

			echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/Ppi_mahasiswa'>";

		}else{

			$this->load->view('login');

		}

	}

}

?>

