﻿<!DOCTYPE html>
<?php
/*error_reporting(0);
$session=isset($_SESSION['mahasiswa_login']) ? $_SESSION['mahasiswa_login']:'';

if($session!=""){*/
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard Admin | SMK MAJU MAPAN</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="<?php echo base_url()?>assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="<?php echo base_url()?>assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="<?php echo base_url()?>assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />-->
   <!-- select2 CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/select2/select2.min.css">
    <!-- chosen CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/chosen/bootstrap-chosen.css">
    <!-- DatePicker -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/datapicker/datepicker3.css">
    <script src="<?php echo base_url()?>assets/js/datapicker/bootstrap-datepicker.js"></script>
    
    <!-- Bootstrap -->
   <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
       <!-- x-editor CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/editor/select2.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/editor/datetimepicker.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/editor/bootstrap-editable.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/editor/x-editor-style.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/data-table/bootstrap-editable.css">
    
    <link rel="stylesheet" href="<?php echo base_url()?>assets/style.css">
    <!-- Password -->
    <script src="<?php echo base_url()?>assets/js/password-meter/bootstrap-show-password.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url()?>assets/sweet_alert/sweetalert.js"></script> 
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/sweet_alert/sweetalert.css">
    <?php
    //Function TinyMce------------------------------------------------------------------
		echo'
		<!-- TinyMCE -->
		<script type="text/javascript" src="'.base_url().'assets/js/tiny_mce/tiny_mce_src.js"></script>
		<script type="text/javascript">
			tinyMCE.init({
				// General options
				mode : "textareas",
				theme : "advanced",
				plugins : "pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave",

				// Theme options
				theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
				theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
				theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
				theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft",
				theme_advanced_toolbar_location : "top",
				theme_advanced_toolbar_align : "left",
				theme_advanced_statusbar_location : "bottom",
				theme_advanced_resizing : true,

				// Example content CSS (should be your site CSS)
				//content_css : "'.base_url().'system/application/views/themes/css/BrightSide.css",

				// Drop lists for link/image/media/template dialogs
				//"'.base_url().'media/lists/image_list.js"
				template_external_list_url : "lists/template_list.js",
				external_link_list_url : "lists/link_list.js",
				external_image_list_url : "'.base_url().'index.php/webadmin/image_list/",
				media_external_list_url : "lists/media_list.js",

				// Style formats
				style_formats : [
					{title : \'Bold text\', inline : \'b\'},
					{title : \'Red text\', inline : \'span\', styles : {color : \'#ff0000\'}},
					{title : \'Red header\', block : \'h1\', styles : {color : \'#ff0000\'}},
					{title : \'Example 1\', inline : \'span\', classes : \'example1\'},
					{title : \'Example 2\', inline : \'span\', classes : \'example2\'},
					{title : \'Table styles\'},
					{title : \'Table row 1\', selector : \'tr\', classes : \'tablerow1\'}
				],
				//disabled relative urls
				relative_urls : false,

				// Replace values for the template plugin
				template_replace_values : {
					username : "Some User",
					staffid : "991234"
				}
			});
		</script>';
	?>
    
</head>
<body>
    <div id="wrapper">
         <div class="navbar navbar-inverse navbar-fixed-top" style="background-color: yellow;">
            <div class="adjust-nav" >
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" 
                    data-target=".sidebar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="">
                        <img src="<?php echo base_url()?>assets/logo.png" width="15%" height="15%"/>

                    </a>
                </div>
            </div>
        </div>
        <!-- /. NAV TOP  -->
       <nav class="navbar-default navbar-side" role="navigation">
        <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li class="active-link">
                        <a href="<?php echo base_url('index.php'); ?>" ><i class="fa fa-desktop "></i>Dashboard <span class="badge">Included</span></a>
                    </li>
                
                    <li>
                        <a href="ui.html"><i class="fa fa-table "></i>UI Elements  <span class="badge">Included</span></a>
                    </li>
                    <li>
                        <a href="blank.html"><i class="fa fa-edit "></i>Blank Page  <span class="badge">Included</span></a>
                    </li>

                    <li>
                        <a href="#"><i class="fa fa-qrcode "></i>My Link One</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-bar-chart-o"></i>My Link Two</a>
                    </li>

                    <li>
                        <a href="#"><i class="fa fa-edit "></i>My Link Three </a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-table "></i>My Link Four</a>
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-edit "></i>My Link Five </a>
                    </li>
                    
                </ul>
                            </div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                
            <?php echo $contents; ?>
            <!-- /. ROW  --> 
    		</div>
             <!-- /. PAGE INNER  -->
        </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
    <div class="footer" style="text-align: center;">
      
    
            <div class="row">
                <div class="col-lg-12" >
                    &copy;  2022 Design by: <a href="http://binarytheme.com" style="color:#fff;" target="_blank">www.binarytheme.com</a>
                </div>
            </div>
        </div>
          



     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="<?php echo base_url()?>assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="<?php echo base_url()?>assets/js/custom.js"></script>
    <!-- chosen JS
		============================================ -->
    <script src="<?php echo base_url()?>assets/js/chosen/chosen.jquery.js"></script>
    <script src="<?php echo base_url()?>assets/js/chosen/chosen-active.js"></script>
    <!-- select2 JS
		============================================ -->
    <script src="<?php echo base_url()?>assets/js/select2/select2.full.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/select2/select2-active.js"></script>
      <!-- data table JS
		============================================ -->
    <script src="<?php echo base_url()?>assets/js/data-table/bootstrap-table.js"></script>
    <script src="<?php echo base_url()?>assets/js/data-table/tableExport.js"></script>
    <script src="<?php echo base_url()?>assets/js/data-table/data-table-active.js"></script>
    <script src="<?php echo base_url()?>assets/js/data-table/bootstrap-table-editable.js"></script>
    <script src="<?php echo base_url()?>assets/js/data-table/bootstrap-editable.js"></script>
    <script src="<?php echo base_url()?>assets/js/data-table/bootstrap-table-resizable.js"></script>
    <script src="<?php echo base_url()?>assets/js/data-table/colResizable-1.5.source.js"></script>
    <script src="<?php echo base_url()?>assets/js/data-table/bootstrap-table-export.js"></script>
      
<!-- 
<script type="text/javascript">
$(function() {
    /*$('#loading').ajaxStart(function(){
        $(this).fadeIn();
    }).ajaxStop(function(){
        $(this).fadeOut();
    });*/

    $('#active-link a').click(function() {
        var url = $(this).attr('href');
        $('#page-inner').load(url);
        return false;
    });
});
</script> -->
    
   
</body>
</html>
<!-- Hide / show password -->
<script>
 $(document).ready(function() {
	$(".glyphicon").bind("click", function() {
	 
	if ($('#pwd').attr('type') =='password'){
	$('#pwd').attr('type','text');
	$('.glyphicon').removeClass('glyphicon-eye-open');
	$('.glyphicon').addClass('glyphicon-eye-close');
	}else if($('#pwd').attr('type') =='text'){
	$('#pwd').attr('type','password');
	$('.glyphicon').removeClass('glyphicon-eye-close');
	$('.glyphicon').addClass('glyphicon-eye-open');
	}
	})
	});
</script>
<?php /*}
else{
echo "<meta http-equiv='refresh' content='0; url=".base_url()."index.php/Login'>";
}*/
?>
