<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Login | Akper Dharma Husada Kota Kediri</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">

    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.css">
    
    
    <style>
    	body {
    font-family: "Lato", sans-serif;
}



.main-head{
    height: 150px;
    background: #FFF;
   
}

.sidenav {
    height: 100%;
    background-color: #000;
    overflow-x: hidden;
    padding-top: 20px;
}


.main {
    padding: 0px 10px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
}

@media screen and (max-width: 450px) {
    .login-form{
        margin-top: 5%;
    }

    .register-form{
        margin-top: 10%;
    }
}

@media screen and (min-width: 768px){
    .main{
        margin-left: 40%; 
    }

    .sidenav{
        width: 40%;
        position: fixed;
        z-index: 1;
        top: 0;
        left: 0;
    }

    .login-form{
        margin-top: 10%;
    }

    .register-form{
        margin-top: 20%;
    }
}


.login-main-text{
    margin-top: 20%;
    padding: 60px;
    color: #fff;
}

.login-main-text h2{
    font-weight: 300;
}

.btn-black{
    background-color: #000 !important;
    color: #fff;
}
    	
    </style>
    
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

 
 	
    <div class="container-fluid" style="margin-top: 100px;">
        <div class="sidenav">
         <div class="" style="margin-top: -20px">
            <img src="<?php echo base_url()?>assets/img/bg_login.jpg" width="550px" height="640px">
         </div>
      </div>
      <div class="main">
         <div class="col-md-12 col-sm-12">
            <div class="login-form">
                <?php echo form_open('Login/Auth');?>
                  <div class="form-group">
                     <label>User Name</label>
                     <input type="text" name="Nim" class="form-control" placeholder="User Name">
                  </div>
                  <div class="form-group">
                     <label>Password</label>
                     <input type="password" name="Pswd" class="form-control" placeholder="Password">
                  </div>
                  <button type="submit" class="btn btn-success">Login</button>
                  
               </form>
            </div>
            <br>
        	
            <div class="alert alert-warning">
            	<p>1. Username dan Password Menggunakan <b>NIM</b></p>
            	<p>2. NIM tidak menggunakan tanda <b>titik (.)</b> Contoh : <b>201649001</b></p>
            	<p>3. Demi Keamanan Informasi Anda, Silahkan Ganti Password Anda Pada Halaman Dashboard</p>
            </div>
         </div>
         
         
         
            <div class="footer">
       		<div class="row">
                <div class="col-lg-12" > &copy;  2020 Akper Dharma Husada | Kota Kediri
                </div>
            </div>
        </div>
         
      </div>
 
    </div>

 </body>   
    <!-- bootstrap JS
		============================================ -->
    <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
    

</html>