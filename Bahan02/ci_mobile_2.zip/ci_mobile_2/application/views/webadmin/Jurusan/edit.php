<!-- Digunakan untuk menampikan Pesan/notifikasi -->
<div id="notifications"><?php echo $this->session->flashdata('msg'); ?></div>
<!-- ================================================================= -->
<div class="row">    
    <div class="col-md-12">
        <h2>Ubah Data Jurusan</h2>
    </div>
</div>
                <!-- /. ROW  -->
    <hr>
    <?php 
    foreach ($jurusan as $data);
    echo form_open('Jurusan/update');?>
    <!-- untuk menyimpan data id / fields yang menjadi primary key pada tabel -->
    <input type="hidden" name="id" value="<?php echo $data->id;?>">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
            <div class="form-group">
				<label>Nama Jurusan</label>
				<input type="text" name="Nama" class="form-control" value="<?php echo $data->Nama;?>">
			</div>
            
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6 col-md-6">
            <input type="submit" class="btn btn-success" value="Simpan">
        </div>
    </div>
    </<form> 
<!-- /. ROW  -->
