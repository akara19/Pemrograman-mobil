<!-- Digunakan untuk menampikan Pesan/notifikasi -->
<div id="notifications"><?php echo $this->session->flashdata('msg'); ?></div>
<!-- ================================================================= -->
<div class="row">    
    <div class="col-md-12">
        <h2>Insert Data Jurusan</h2>
    </div>
</div>
                <!-- /. ROW  -->
    <hr>
    <?php echo form_open('Jurusan/insert');?>
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
            <div class="form-group">
				<label>Nama Jurusan</label>
				<input type="text" name="Nama" class="form-control">
			</div>
            
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <input type="submit" class="btn btn-success" value="Simpan">
            <a href="<?php echo base_url('index.php/Jurusan/Select');?>">
            <input type="button" class="btn btn-warning" value="Lihat Data">
            </a>
        </div>
    </div>
    </<form> 
<!-- /. ROW  -->
