<div class="content ">
        <div class="container">
          <div class="row">
            <div class="col">
              <div class="row">
                <div class="box">
                  <a href="<?php echo base_url('index.php/JenisBayar'); ?>">
                    <img src="<?php echo base_url('img/profil.png'); ?>" alt="user">
                  </a>
                </div>
              <div class="row">
                <p id="title1">Jenis Bayar</p>
              </div> 
              </div>  
            </div>
            <div class="col">
              <div class="row">
                <div class="box">
                  <a href="<?php echo base_url('index.php/Siswa'); ?>"> 
                    <img src="<?php echo base_url('img/agenda.png'); ?>" alt="search">
                  </a>
              </div>
              <div class="row">
                <p id="title2">Siswa</p>
              </div>
              </div> 
            </div>
            <div class="col">
              <div class="row">
                <div class="box">
                  <a href="https://rilis.co.id/profil">
                    <img src="<?php echo base_url('img/struktur.png'); ?>" alt="doc">
                  </a>
              </div>
              <div class="row">
                <p id="title3">Struktur</p> 
              </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col">
              <div class="row">
                <div class="box" id="row2">
                  <a href="<?php echo base_url('index.php/Profile/kantor')?>">
                    <img src="<?php echo base_url('img/kantor.png'); ?>" alt="phone">
                  </a>
                </div>
              <div class="row">
                <p id="title4">Kantor</p>
              </div> 
              </div>  
            </div>
            <div class="col">
              <div class="row">
                <div class="box" id="row2">
                  <a href="https://rilis.co.id/ucapan">
                    <img src="<?php echo base_url('img/galeri.png'); ?>" alt="galeri">
                  </a>
                </div>
              </div>
              <div class="row">
                <p id="title5">Galeri</p>
              </div>
            </div>
            <div class="col">
              <div class="row">
                <div class="box" id="row2">
                 <a href="https://rilis.co.id">
                   <img src="<?php echo base_url('img/website.png'); ?>" alt="clock">
                 </a> 
                </div>
              </div>
              <div class="row">
                <p id="title6">Website</p> 
              </div>
            </div>
          </div>
        </div>
      </div> 
    </div> 