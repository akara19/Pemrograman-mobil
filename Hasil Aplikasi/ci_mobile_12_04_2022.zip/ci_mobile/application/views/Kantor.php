<div class="content ">
	<div class="container">
        <div class="row">
			Alamat : Jl. Nusa Indah No.16 <br>
			Telp : 0354-123456 <br>
			Kab.Kediri.
		</div>
	</div>
</div>