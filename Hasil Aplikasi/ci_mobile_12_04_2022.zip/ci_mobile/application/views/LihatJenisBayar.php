<div class="content">
	<div class="container">
        <div class="row">
        <table class="table">
            <th>Jenis Bayar</th>
            <th>Nominal</th>
			<th>Aksi</th>
			<?php 
                foreach($jenis as $_jenis){
                    echo    "<tr>".
                                "<td>".$_jenis->Jenis_bayar."</td>".
                                "<td>".$_jenis->Nominal."</td>".
								"<td>".
									anchor('JenisBayar/Edit/'.$_jenis->Kode,'Edit',
                                    array('Title'=>'Edit Data','class'=>'btn btn-info')).
									
                                    anchor('JenisBayar/Delete/'.$_jenis->Kode,'Delete',
                                    array('Title'=>'Delete Data','class'=>'btn btn-danger')).
								"</td>".
                            "</tr>";
                };
            ?>
        </table>    
		</div>
	</div>
</div>
