<div class="content">
	<div class="container-fluid">
        <div class="row">
			<?php echo form_open_multipart('Siswa/Simpan');?>
                <div class="form-group">
                    <label>Nama Siswa</label>
                    <input type="text" class="form-control" name="Nama">
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" class="form-control" name="Alamat">
                </div>
				
                <div class="form-group">
                    <input type="submit" value="Simpan" class="btn btn-success">
                    <a href="<?php echo base_url('index.php/Siswa/Lihat'); ?>">
                        <input type="button" value="Lihat Data" 
                        class="btn btn-danger">
                    </a>
                </div>
            </form>
            
		</div>
	</div>
</div>
