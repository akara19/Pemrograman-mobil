<div class="content">
	<div class="container-fluid">
        <div class="row">
			<?php 
				echo form_open_multipart('Siswa/Update');
				 foreach($siswa as $_siswa);
			?>
                <div class="form-group">
                    <label>Nama Siswa</label>
					<input type="hidden" name="Kode" 
                    value="<?php echo $_siswa->Kode; ?>">
                    
                    <input type="text" name="Nama" class="form-control" 
                    value="<?php echo $_siswa->Nama; ?>">
                </div>
                <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" name="Alamat" class="form-control" 
                    value="<?php echo $_siswa->Alamat; ?>">
                </div>
				
                <div class="form-group">
                    <input type="submit" value="Update" class="btn btn-success">
                    <a href="<?php echo base_url('index.php/Siswa/Lihat'); ?>">
                        <input type="button" value="Lihat Data" class="btn btn-danger">
                    </a>
                </div>
            </form>
            
		</div>
	</div>
</div>
