<div class="content">
	<div class="container">
        <div class="row">
        <table class="table">
            <th>Nama</th>
            <th>Alamat</th>
			<th>Aksi</th>
			<?php 
                foreach($siswa as $_siswa){
                    echo    "<tr>".
                                "<td>".$_siswa->Nama."</td>".
                                "<td>".$_siswa->Alamat."</td>".
								"<td>".
									anchor('Siswa/Edit/'.$_siswa->Kode,'Edit',
                                    array('Title'=>'Edit Data','class'=>'btn btn-info')).
									
                                    anchor('Siswa/Delete/'.$_siswa->Kode,'Delete',
                                    array('Title'=>'Delete Data','class'=>'btn btn-danger')).
								"</td>".
                            "</tr>";
                };
            ?>
        </table>    
		</div>
	</div>
</div>
