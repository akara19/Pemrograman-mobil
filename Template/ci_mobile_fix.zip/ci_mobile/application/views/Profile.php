<div class="content ">
	<div class="container">
        <div class="row">
			Nama Saya : Bagus
		</div>
	</div>
</div>