<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo base_url('css/style.css') ;?>">

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">

    <title>RILISAN</title>
  </head>
  <body>

      <div class="header">
        <div class="container">
          <div class="row">
            <div class="col">
              <img id="logo" 
              src="<?php echo base_url('img/rilisan.png'); ?>" alt="logo">
            </div>
          </div>
          <div class="row">
            <div class="col">
              <h6 id="title-header">APLIKASI ANDROID <br>RILIS INFORMASI</h6>
            </div>
          </div>
        </div>  
      </div>


      <div class="background">
          <img id="background" src="<?php echo base_url('img/background.png'); ?>" alt="background">
        <div class="slider">
          <div class="container">
            <div class="row">
              <div class="col">
                <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                      <img class="d-block w-100" src="<?php echo base_url('img/slider1.png'); ?>" alt="First slide" id="slider1">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100" src="<?php echo base_url('img/slider2.png'); ?>" alt="First slide" id="slider1">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100" src="<?php echo base_url('img/slider1.png'); ?>" alt="First slide" id="slider1">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        

        <?php echo $contents; ?>
        
          <div class="footer">
            <div class="container">
              <div class="row">
                <div class="col">
                  <h5 id="title-footer">
                    Ikuti Kami Di Media Sosial
                  </h5>
                </div>
              </div>
              <div class="row">
                <div class="col-md-auto">
                  <a href="https:/wa.me/6282187213232">
                    <img src="<?php echo base_url('img/wa.png'); ?>" alt="wa" id="sosmed">
                  </a>
                  <a href="https://facebook.com/rilisvideo">
                    <img src="<?php echo base_url('img/fb.png'); ?>" alt="fb" id="sosmed">
                  </a>
                  <a href="https://instagram.com/ilhamnursenja">
                    <img src="<?php echo base_url('img/ig.png'); ?>" alt="ig" id="sosmed">
                  </a>
                  <a href="https://twitter.com/ilham_nursenja">
                    <img src="<?php echo base_url('img/tw.png'); ?>" alt="tw" id="sosmed">
                  </a>
                  <a href="https://youtube.com/c/rilisan">
                    <img src="<?php echo base_url('img/yt.png'); ?>" alt="yt" id="sosmed">
                  </a>
                </div>
              </div>
            </div>  
          </div>
        </div>
       

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>